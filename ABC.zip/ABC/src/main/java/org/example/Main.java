package org.example;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BookService service = new BookService();
        Scanner scanner = new Scanner(System.in);

        System.out.println("📚 Welcome to the Book Manager!");
        System.out.println("==============================");

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add a new book");
            System.out.println("2. List all books");
            System.out.println("3. Find book by ISBN");
            System.out.println("4. Remove a book");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author name: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();

                    service.addBook(new Book(title, author, isbn));
                    System.out.println("✅ Book added successfully!");
                    break;

                case "2":
                    List<Book> books = service.getAllBooks();
                    if (books.isEmpty()) {
                        System.out.println("⚠️ No books found.");
                    } else {
                        System.out.println("\n📚 Book List:");
                        for (Book b : books) {
                            System.out.println("- " + b.getTitle() + " by " + b.getAuthor() + " (ISBN: " + b.getIsbn() + ")");
                        }
                    }
                    break;

                case "3":
                    System.out.print("Enter ISBN to search: ");
                    String findIsbn = scanner.nextLine();
                    Book found = service.findByIsbn(findIsbn);
                    if (found != null) {
                        System.out.println("✅ Found: " + found.getTitle() + " by " + found.getAuthor());
                    } else {
                        System.out.println("❌ Book not found.");
                    }
                    break;

                case "4":
                    System.out.print("Enter ISBN to remove: ");
                    String removeIsbn = scanner.nextLine();
                    boolean removed = service.removeBook(removeIsbn);
                    System.out.println(removed ? "🗑️ Book removed." : "❌ No book found with that ISBN.");
                    break;

                case "5":
                    System.out.println("👋 Goodbye!");
                    return;

                default:
                    System.out.println("⚠️ Invalid choice, try again.");
            }
        }
    }
}

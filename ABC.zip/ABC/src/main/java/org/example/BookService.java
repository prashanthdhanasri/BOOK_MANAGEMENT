package org.example;

import java.util.ArrayList;
import java.util.List;

public class BookService {
    private final String filePath = "books.json";
    private List<Book> books;

    public BookService() {
        books = FileUtils.loadBooks(filePath);
    }

    public void addBook(Book book) {
        books.add(book);
        FileUtils.saveBooks(books, filePath);
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }

    public Book findByIsbn(String isbn) {
        return books.stream()
                .filter(b -> b.getIsbn().equals(isbn))
                .findFirst()
                .orElse(null);
    }

    public boolean removeBook(String isbn) {
        Book book = findByIsbn(isbn);
        if (book != null) {
            books.remove(book);
            FileUtils.saveBooks(books, filePath);
            return true;
        }
        return false;
    }
}

package org.example;

import org.example.Book;
import org.example.BookService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;

public class BookServiceTest {

    private BookService service;
    private static final String TEST_FILE = "test_books.json";

    @BeforeEach
    void setup() {
        // Use a separate file for testing, so real data isn't affected
        File file = new File(TEST_FILE);
        if (file.exists()) {
            file.delete();
        }

        // Create a new BookService instance
        service = new BookService() {
            {
                // Override the file path for test isolation
                try {
                    var field = BookService.class.getDeclaredField("filePath");
                    field.setAccessible(true);
                    field.set(this, TEST_FILE);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

    @Test
    void testAddAndFindBook() {
        Book book = new Book("Test Book", "Tester", "123");
        service.addBook(book);

        Book found = service.findByIsbn("123");
        Assertions.assertNotNull(found, "Book should be found by ISBN");
        Assertions.assertEquals("Test Book", found.getTitle());
        Assertions.assertEquals("Tester", found.getAuthor());
    }

    @Test
    void testRemoveBook() {
        service.addBook(new Book("Temp", "Author", "999"));
        boolean removed = service.removeBook("999");
        Assertions.assertTrue(removed, "Book should be removed successfully");

        Book found = service.findByIsbn("999");
        Assertions.assertNull(found, "Removed book should no longer exist");
    }

    @Test
    void testFindBookNotFound() {
        Book found = service.findByIsbn("no-such-isbn");
        Assertions.assertNull(found, "Should return null for missing book");
    }
}
